
## 9. 最终回归

在 Ubuntu 24.04.5 + ROS 2 Jazzy 容器内，从完整源码重新构建并逐条执行验收命令：

```text
cmake -S . -B /tmp/build && cmake --build /tmp/build   -> 成功
/tmp/build/public_tests                                -> PUBLIC 2/2
/tmp/build/debug_task                                  -> S1 no 5 yes 0
python3 tools/validate_structure.py                     -> Structure OK
colcon build --symlink-install                          -> Summary: 1 package finished [9.27s]
```

`ros2 launch warehouse_dispatch warehouse_demo.launch.py` 的执行结果：

```text
launch_exit=0 elapsed=3s
ACCEPT O1 S1
ACCEPT O2 S2
REJECT O3
COMPLETE O1
REJECT O4
WAITED 1
计行数 6
残留进程 none
```

`main` 分支共 4 个提交：模板原始提交、Q1 实现、Q4 修复、Q5 文档。工作区在提交后保持干净。
