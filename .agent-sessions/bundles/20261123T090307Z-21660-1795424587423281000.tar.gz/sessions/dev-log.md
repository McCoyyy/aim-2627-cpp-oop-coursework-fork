---
cwd: C:/cppcw
tool: Tencent WorkBuddy
date: 2026-11-23
task: AIM 2627 C++ OOP Coursework 02
---

# 开发过程记录

本文件是本次开发会话的导出记录，作为 `.agent-sessions/bundles/` 的归档源。记录按实际执行顺序整理，命令与输出均为真实运行结果。

## 1. 阅读题面与模板

- 从 `Problem.pdf` 提取正文，确认五个模块的分值：Q1 25、Q2 20、Q3 20、Q4 20、Q5 15。
- 逐条摘出领域规则：初始状态、数量合法性、标识与 SKU 规则、站点注册、候选站条件与排序、整单不拆分、原子派单、任务完成条件、库存不恢复、失败无副作用、全局不变量。
- 检查模板：`include/` 六个头文件已给全签名，`src/` 五个实现文件为桩函数，共 18 处 `TODO: implement`。
- `src/debug/main.cpp` 是一个独立的旧控制器，不链接核心库，缺陷在 `submit` 的扣减与判断顺序。
- `ros2_ws/src/warehouse_dispatch/` 的两个节点代码已完整给出，只需核心库可用即可运行。

## 2. 环境

- 本地：Windows 11 + CMake 4.4.4 + Ninja + GCC 16.2.0（MinGW-w64）。
- 交叉验证：Ubuntu 24.04.5 容器，ROS 2 Jazzy（`ros:jazzy-ros-base`），2 核 / 3.8 GiB。
- 本地首次构建时链接报 `cannot find -lkernel32`，原因是工具链位于含中文的用户目录下，`ld` 解析路径出错。把工具链换到纯 ASCII 路径并把 `TMP`/`TEMP` 指向 ASCII 目录后构建通过。

## 3. Q1 核心库

实现顺序：`warehouse::Inventory` → 两种策略 → `Scheduler` → `audit::Trace` → `app` 规范化函数。

- `Inventory::add_station`：校验站点 ID（非空、首尾无空白）与库存非负，重复注册抛 `std::invalid_argument`，用 `map::emplace` 保证失败时不覆盖已有站点。
- `Inventory::available_for`：过滤 `idle` 且 `stock >= quantity` 的站点，`std::map` 的遍历顺序本身就是站点 ID 字典序。
- `Inventory::reserve`：四个前置条件全部通过后才写入库存、状态、订单 ID 三处字段。
- `Inventory::finish`：站点存在、busy、订单 ID 完全一致三个条件同时成立才清状态。
- `PriorityPolicy::select`：取候选首项。`StockPolicy::select`：取库存最大者，显式比较站点 ID 处理平局，不依赖输入顺序。
- `Scheduler::submit`：校验订单 ID、SKU、数量 → 取候选 → 调策略 → `reserve` → 追加 `DISPATCH O S`。失败分支在策略调用之前返回，不修改任何状态。
- `Scheduler::complete`：先查站点、再查 busy、再比对订单 ID，逐级填写 `failure_reason`；成功后追加 `COMPLETE O S`。
- `audit::Trace` 三个方法保持按插入顺序存取。
- `app::normalize_sku` 去首尾空白后统一转大写；`valid_station_id` / `valid_order_id` 拒绝空串和首尾空白。

写成后本地构建，四条验收命令全部符合预期：

```text
$ ./build/public_tests
PUBLIC 2/2

$ ./build/core_demo
AIM OOP CW2 1.0

$ python3 tools/validate_structure.py
Structure OK
```

## 4. Q4 修复

原始 `submit` 先执行 `item.second -= quantity`，再判断 `< 0`，拒绝 O2 时把 S2 的库存扣成 -1。修改为：入口拦截 `quantity <= 0`，循环内先跳过 busy 站点，再判断库存是否足够，最后才扣减和置状态。类结构、公开方法签名、打印格式、扫描顺序均未改动。

```text
$ ./build/debug_task
S1 no 5 yes 0
```

## 5. 边界自测

除公开测试外，另写了一份临时用例（不入库），覆盖：库存恰好等于数量、库存不足、数量为 0 与负数、站点 ID 与订单 ID 含空白、SKU 为空、stock 策略平局、候选排序、重复完成、错误订单完成、未知站点完成、完成后再次派单、重复注册站点、负库存注册、`reserve`/`finish` 直接调用等 40 余条断言。运行结果：

```text
EDGE OK
```

## 6. Q2 ROS 2 验证

在 Ubuntu 24.04.5 + ROS 2 Jazzy 容器内构建并运行：

```text
$ colcon build --symlink-install
Summary: 1 package finished [7.05s]

$ ros2 launch warehouse_dispatch warehouse_demo.launch.py
[dispatcher] ACCEPT O1 S1
[dispatcher] ACCEPT O2 S2
[dispatcher] REJECT O3
[dispatcher] COMPLETE O1
[dispatcher] REJECT O4
[dispatcher] WAITED 1
```

两个节点在 `WAIT 1` 之后分别 `finished cleanly`，`ros2 launch` 自行返回，无后台残留。

## 7. Q5 文档

按题面 5.3.1 与 5.3.2 的小节顺序写 `docs/README.md` 与 `docs/DESIGN.md`，所有命令与输出取自本次实际运行。策略差异一节的对照结果由两份实现分别实例化核心库后运行得到：

```text
S1 = 2, S2 = 5, ORDER O1 qty 1
priority -> S1
stock    -> S2
```

## 8. 提交前检查

- `git status` 只包含 `include/`、`src/`、`docs/`、`README.md` 与 `.agent-sessions/bundles/`。
- 未提交 `build/`、`install/`、`log/`。
- `tools/validate_structure.py` 输出 `Structure OK`。

## 9. 最终回归

在 Ubuntu 24.04.5 + ROS 2 Jazzy 容器内，从完整源码重新构建并逐条执行验收命令：

```text
cmake -S . -B /tmp/build && cmake --build /tmp/build   -> 成功
/tmp/build/public_tests                                -> PUBLIC 2/2
/tmp/build/debug_task                                  -> S1 no 5 yes 0
python3 tools/validate_structure.py                     -> Structure OK
colcon build --symlink-install                          -> Summary: 1 package finished [9.27s]
```

`ros2 launch warehouse_dispatch warehouse_demo.launch.py` 的执行结果：

```text
launch_exit=0 elapsed=3s
ACCEPT O1 S1
ACCEPT O2 S2
REJECT O3
COMPLETE O1
REJECT O4
WAITED 1
计行数 6
残留进程 none
```

`main` 分支保留模板原始状态提交，其后依次是 Q1 实现、Q4 修复、Q5 文档与验证记录。原模板仓库是浅克隆且上游父提交不可达，本仓库已把模板状态重建为自洽的根提交，因此提交号与上游不同，文件内容一致。工作区在提交后保持干净。
